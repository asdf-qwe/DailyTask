package com.project4.DailyTask.domain.team.dto;

public record CreateTeamRequest(String name, String description ){}