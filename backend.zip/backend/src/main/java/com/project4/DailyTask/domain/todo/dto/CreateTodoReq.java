package com.project4.DailyTask.domain.todo.dto;

import java.time.LocalDate;

public record CreateTodoReq(String title, LocalDate dueDate){}